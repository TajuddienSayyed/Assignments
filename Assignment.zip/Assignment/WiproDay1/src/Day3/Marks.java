package Day3;

import java.util.Scanner;

public class Marks {
//1. Write a program to store and print the marks of 5 students using 1D array.

	public static void main(String[] args) {
		int a[]=new int[5];
		Scanner s = new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			System.out.println("Enter a subject"+i+"");
				a[i]= s.nextInt();
		}
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		// TODO Auto-generated method stub

	}

}
