package Day3;

import java.util.Scanner;

public class JumpingOnClouds {
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		//int n= s.nextInt();
		int a[]= {0,1,0,0,1,0,0};
		
		int c=0;
		int d = 0;

        for (int i = 0; i < a.length;i++) { 
            if (i+1 <a.length && a[i+1]!=1) {
            	i+=2;
            } 
            else {
            	continue;
            }
            d++;
        }
        System.out.println(d);

	}

}
