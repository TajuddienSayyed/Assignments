package Day3;

import java.util.Scanner;

public class Second {
//2. Write a program to store and print the marks of students present in 3 classrooms where in each classroom there are 5 students. 

	public static void main(String[] args) {
		int a[][]=new int[3][5];
		Scanner s = new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.println("Enter a subject"+j+"of student "+i+"");
				a[i][j]= s.nextInt();
			}
			
		}
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		// TODO Auto-generated method stub

	}
		// TODO Auto-generated method stub

	}

