package Day3;

import java.util.Scanner;

public class Fifth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		5. Write a program to store and print the marks of students.
//
//		 
//
//		schools		classroom	Students
//
//		0		0 		0 - 3
//
//				1		0 - 2
//
//		 
//
//		1		0		0 - 3
//
//		 
//
//		2		0		0 - 5
//
//				1		0 - 4
//
//				2		0 - 2
			int a[][][]=new int[3][][];
			a[0]= new int[2][];
			a[1]= new int[1][4];
			a[2]= new int[3][];
			
			a[0][0]= new int[4];
			a[0][1]= new int[3];
			a[2][0]= new int[6];
			a[2][1]= new int[5];
			a[2][2]= new int[3];

			Scanner s = new Scanner(System.in);
			for(int i=0;i<a.length;i++)
			{
				for(int j=0;j<a[i].length;j++)
				{
					for(int k=0;k<a[i][j].length;k++)
					{
					System.out.println("Enter a school "+i+" of class "+j+" of student"+k);
					a[i][j][k]= s.nextInt();
				}
				
			}
			}
				for(int i=0;i<a.length;i++)
				{
					for(int j=0;j<a[i].length;j++)
					{
						for(int k=0;k<a[i][j].length;k++)
						{
						System.out.print(a[i][j][k]+" ");
						}
						System.out.println();
					
				}
					System.out.println();
		}
		}
	}