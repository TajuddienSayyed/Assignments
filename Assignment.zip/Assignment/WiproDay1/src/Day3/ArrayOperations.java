package Day3;

public class ArrayOperations {
	public static int accessElement(int arr[],int index)
	{
		if(index<0||index>=arr.length)
		{
			System.out.println("Index Out of Bounds");
			return -1;
		}
		else
		{
			return arr[index];
		}
	}
	public static int[] insertElement(int arr[],int index,int ele)
	{
		if(index<0||index>=arr.length)
		{
			System.out.println("Index Out of Bounds");
			return arr;
		}
		int []newArray= new int[arr.length+1];
		for(int i=0;i<index;i++)
		{
			newArray[i]=arr[i];
		}
		newArray[index]=ele;
		for(int i=index+1;i<newArray.length;i++)
		{
			newArray[i]=arr[i-1];
		}
		return newArray;
	}
	public static int[] delElement(int arr[],int index)
	{
		if(index<0||index>=arr.length)
		{
			System.out.println("Index Out of Bounds");
			return arr;
		}
		int []newArray= new int[arr.length-1];
		for(int i=0;i<index;i++)
		{
			newArray[i]=arr[i];
		}
		for(int i=index+1;i<arr.length;i++)
		{
			newArray[i-1]=arr[i];
		}
		return newArray;
		
	}
	public static int[] updateElement(int arr[],int index,int ele)
	{
		if(index<0||index>=arr.length)
		{
			System.out.println("Index Out of Bounds");
			return arr;
		}
		arr[index]=ele;
		return arr;
	}
	public static int[] ReverseArray(int arr[])
	{
		int [] reverse= new int[arr.length];
		for(int i=0;i<arr.length;i++)
		{
			reverse[i]=arr[arr.length-1-i];
		}
		return reverse;
		
	}
	public static int[] sliceElement(int arr[],int stindex,int endindex)
	{
		if(stindex<0||endindex>=arr.length|| stindex>endindex)
		{
			System.out.println("Index Out of Bounds");
			return new int[0];
		}
		int[]slicedArray= new int[endindex-stindex+1];
		for(int i=stindex;i<=endindex;i++)
		{
			slicedArray[i-stindex]=arr[i];
		}
		return slicedArray;
	}
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int []a= {10,20,30,40,50,60,70};
		//int[] insertElement = insertElement(a,2,60);
		//int[] delElement = delElement(a,1);
		//int[] reverseArray = ReverseArray(a);
		//int[] updateElement = updateElement(a,2,90);
		int[] sliceElement = sliceElement(a,1,4);
		for(int i=0;i<sliceElement.length;i++)
		{
			System.out.print(sliceElement[i]+" ");
		}
		//System.out.println(accessElement(a,3));
	}

}
