package Day3;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[5];
		Scanner s = new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			System.out.println("Enter a subject"+i+"");
				a[i]= s.nextInt();
		}
		System.out.println("Enter a element to search: ");
		int k= s.nextInt();
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==k)
			System.out.print("ELement found at index "+i);
			//break;
		}


	}

}
