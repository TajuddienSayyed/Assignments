package Day3;

import java.util.Scanner;

public class Third {
//3. Write a program to store and print the marks of students present in 3 schools where in each school there are 2 class rooms and in each classroom there are 5 students.

	public static void main(String[] args) {
		int a[][][]=new int[3][2][5];
		Scanner s = new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				for(int k=0;k<a[j].length;k++)
				{
				System.out.println("Enter a school "+i+" of class "+j+" of student"+k);
				a[i][j][k]= s.nextInt();
			}
			
		}
		}
			for(int i=0;i<a.length;i++)
			{
				for(int j=0;j<a[i].length;j++)
				{
					for(int k=0;k<a[j].length;k++)
					{
					System.out.print(a[i][j][k]);
					}
					System.out.println();
				
			}
				System.out.println();
	}
	}
}
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
