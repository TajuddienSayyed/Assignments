package com.wipro.first;

import java.util.Scanner;

public class Avgcal {
	    public static double calculateAvg(int c) {
	        //double total = mark1 + mark2 + mark3 + mark4 + mark5;
	        return c / 5;
	    }
	    public static String Grade(double average) {
	        if (average >= 90) {
	            return "A";
	        } else if (average >= 75) {
	            return "B";
	        } else if (average >= 50) {
	            return "C";
	        } else {
	            return "D";
	        }
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        System.out.println("Enter  how many subjects : ");
	       int  n = scanner.nextInt();
	        
	        int n1,c=0;
	        for(int i=0;i<n;i++)
	        {
	        	 n1 = scanner.nextInt();
	        	 c+=n1;
	        }

	        double average = calculateAvg(c);

	        String grade = Grade(average);

	        System.out.println("\nAverage Marks: " + average);
	        System.out.println("Grade: " + grade);

	    }
	}

