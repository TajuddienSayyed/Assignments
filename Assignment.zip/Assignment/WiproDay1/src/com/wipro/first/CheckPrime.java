package com.wipro.first;

import java.util.Scanner;

public class CheckPrime {
    static void check(int num)
	{
//		if ((num==2) || (num==3) || (num==5) || (num == 7))
//		{
//			System.out.println("Its a prime.");
//		}
//		else if ((num % 2 == 0) || (num % 3 == 0) || (num % 5 == 0) || (num % 7 == 0))
//		System.out.println("Not a prime.");
//	   else {
//		   System.out.println("Its a prime.");
//	   }
    	int c=0;
    	for(int i=2;i<num;i++){
    		if(num%i==0)
    		{
    			c++;
    		}
    	}
    	if(c==0)
    	{
    		System.out.println(" a prime.");
    	}
    	else
    	{
    		System.out.println(" Not a prime.");
    	}
	}

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a number:");
		int num= s.nextInt();
		check(num);

	}

}
