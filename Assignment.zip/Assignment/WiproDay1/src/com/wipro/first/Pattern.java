package com.wipro.first;

import java.util.Scanner;

public class Pattern {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a number:");
		int num= s.nextInt();
		int c=0;
		 for (int i=1;i<=num;i++) {
	            for (int j=1;j<= i;j++) {
	            	c++;
	                System.out.print(c + " ");
	            }
	            System.out.println();
	        }
	    }

}
