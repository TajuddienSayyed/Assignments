package com.wipro.first;

import java.util.Scanner;

public class Firstprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Hello");
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a number:");
		int num= s.nextInt();
		System.out.println("Input is:"+num);
		//byte, short, long, char, float, double, boolean, string(one word), string(complete line)
		System.out.println("Enter a char:");
		char c= s.next().charAt(0);
		System.out.println("Input is:"+c);
		System.out.println("Enter a byte:");
		byte b= s.nextByte();
		System.out.println("Input is:"+b);
		System.out.println("Enter a short:");
		short sh= s.nextShort();
		System.out.println("Input is: "+sh);
		System.out.println("Enter a float:");
		float f= s.nextFloat();
		System.out.println("Input is: "+f);
		System.out.println("Enter a double:");
		double d= s.nextDouble();
		System.out.println("Input is:"+d);
		boolean bo= s.nextBoolean();
		System.out.println("Input is:"+bo);
		System.out.println("Enter a string:");
		String st = s.next();
		System.out.println("Input is:"+st);
		System.out.println("Enter a string Line:");
		String stl = s.nextLine();
		System.out.print("Input is:"+stl);
		
		
	}

}
