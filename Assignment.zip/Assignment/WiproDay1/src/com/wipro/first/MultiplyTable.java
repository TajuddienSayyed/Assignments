package com.wipro.first;

import java.util.Scanner;

public class MultiplyTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a number:");
		int num= s.nextInt();
		System.out.println("Enter the Range:");
		int r= s.nextInt();
		for (int i = 1; i <= r; i++) {
            System.out.println(num + " x " + i + " = " + (num * i));
        }

	}

}
