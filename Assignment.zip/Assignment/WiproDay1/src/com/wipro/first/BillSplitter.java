package com.wipro.first;

import java.util.Scanner;

public class BillSplitter {
	    public static double calculate(double totalBill, int nop, double tipPercentage) {
	        double tipAmount = (totalBill*tipPercentage)/ 100;
	        
	        double totalBillWithTip = totalBill + tipAmount;
	        
	        return totalBillWithTip;
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter the total bill amount: ");
	        double totalBill = scanner.nextDouble();

	        System.out.println("Enter the number of people: ");
	        int nop = scanner.nextInt();

	        System.out.println("Enter the tip percentage: ");
	        double tipPercentage = scanner.nextDouble();

	        double amountPerPerson = calculate(totalBill, nop, tipPercentage);

	        System.out.println("\nBill Summary:");
	        System.out.println("Total Bill (with tip): "+amountPerPerson);
	        System.out.println("Amount per person: "+ amountPerPerson/nop);
	    }
	}
